package com.ifsp.lucas.api.repository;

import java.util.ArrayList;
import com.ifsp.lucas.api.model.Produto;

public class ProdutoRepository {
	ArrayList<Produto> produtos = new ArrayList<>();
	
	
	
	
}
