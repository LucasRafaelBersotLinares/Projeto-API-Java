package com.ifsp.lucas.api.model;

public class Produto {
	String nome;
	int estoque;
	
	Produto(String nome, int estoque){
		this.nome = nome;
		this.estoque = estoque;
	}
}
