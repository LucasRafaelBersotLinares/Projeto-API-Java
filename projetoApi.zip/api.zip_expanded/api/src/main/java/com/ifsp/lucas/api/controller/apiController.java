package com.ifsp.lucas.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.ifsp.lucas.api.service.ProdutoService;

@RestController
public class apiController {
	ProdutoService produtoRegras = new ProdutoService();
	
	
	@GetMapping(path = "/lista")
	public ResponseEntity<String> helloWorld(){
		return ResponseEntity.ok("Hello World");
	}
	
}
