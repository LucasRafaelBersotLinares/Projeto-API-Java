package com.ifsp.lucas.api.service;

import com.ifsp.lucas.api.repository.ProdutoRepository;

public class ProdutoService {
	ProdutoRepository produtoRepo = new ProdutoRepository();
	
	
	
}
